package com.share2teach.Share2Teach;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Share2TeachApplication {

	public static void main(String[] args) {
		SpringApplication.run(Share2TeachApplication.class, args);
	}

}
