package com.share2teach.Share2Teach;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Share2TeachApplicationTests {

	@Test
	void contextLoads() {
	}

}
