package com.S2T.pgdb.version.Share2Teachh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Share2TeachhApplication {

	public static void main(String[] args) {
		SpringApplication.run(Share2TeachhApplication.class, args);
	}

}
