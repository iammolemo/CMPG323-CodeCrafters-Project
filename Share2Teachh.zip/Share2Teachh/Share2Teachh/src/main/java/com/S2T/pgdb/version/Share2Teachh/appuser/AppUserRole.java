package com.S2T.pgdb.version.Share2Teachh.appuser;

public enum AppUserRole {
    ADMIN,
    MODERATOR,
    EDUCATOR,
    OA_USER
}
