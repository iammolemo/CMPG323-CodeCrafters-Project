package com.S2T.pgdb.version.Share2Teachh.email;

public interface EmailSender {
    void send(String to, String email);
}
