package com.S2T.pgdb.version.Share2Teachh.registration;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@EqualsAndHashCode
@ToString

public class RegistrationRequest {

    //What we want to capture when clients sends registration request
    private final String firstName;
    private final String lastName;
    private final String email;
    private final String password;

}
