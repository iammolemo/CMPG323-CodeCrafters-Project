package com.S2T.pgdb.version.Share2Teachh.registration;

import lombok.AllArgsConstructor;
import lombok.ToString;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "api/v1/share2teach")
@AllArgsConstructor

public class UserRegistrationController {
    //Reference to registration service
    private RegistrationService registrationService;

    //To capture registration from the request body
    @PostMapping
    public String register(@RequestBody RegistrationRequest request) {
        return registrationService.register(request);
    }
}
