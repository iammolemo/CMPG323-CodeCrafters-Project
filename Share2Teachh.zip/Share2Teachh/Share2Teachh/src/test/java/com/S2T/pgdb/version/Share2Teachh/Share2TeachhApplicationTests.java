package com.S2T.pgdb.version.Share2Teachh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Share2TeachhApplicationTests {

	@Test
	void contextLoads() {
	}

}
